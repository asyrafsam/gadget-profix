export const createIcon = className => {
  const icon = document.createElement('i');
  icon.className = className;

  return icon;
};
