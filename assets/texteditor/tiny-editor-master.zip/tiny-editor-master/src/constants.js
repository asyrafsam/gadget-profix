export const BEFORE_BEGIN = 'beforebegin';
export const BEFORE_END = 'beforeend';
export const TOOLBAR_ITEM = '__toolbar-item';
