module.exports = require('./dist/bundle.js');
