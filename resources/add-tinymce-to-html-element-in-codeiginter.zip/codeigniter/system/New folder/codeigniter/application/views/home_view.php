<!doctype html>
<html>
	<head>
		<title>How to Create and Load View in CodeIgniter</title>
	</head>
	<body>
		<h2><?= $content; ?></h2>
		<table>
			<tr>
				<td>Name : </td>
				<td><input type='text' /></td>
			</tr>
			<tr>
				<td>Username : </td>
				<td><input type='text' /></td>
			</tr>
			<tr>
				<td>Email : </td>
				<td><input type='text' /></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type='button' value='Submit' /></td>
			</tr>
		</table>
	</body>
</html>